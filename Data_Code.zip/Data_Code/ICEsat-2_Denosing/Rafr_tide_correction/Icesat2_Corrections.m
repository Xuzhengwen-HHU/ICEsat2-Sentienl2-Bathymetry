%%%%%%%%%%%%对去噪后的光子水深数据做折射和潮汐校正
clear
clc
close all

%% 导入数据
path = 'F:\Data_Code\ICEsat-2_Denosing\Data';
%% 筛选数据
%%2023
filename = 'ATL03_20230516120850_08571907_006_02.h5';%%Cross全富岛和银屿 ##gt1l/r,gt3l可用，优选
tide_20230516_20=(1.03+1.1)/2-0.95;

%%%%%修改
lat1=16.56;
lat2=16.6;
sea_surface_height=2.1;%%去噪程序中得到

HH=tide_20230516_20;
% L:\Icesat2_xzw\Photons_Data_for_denosing\After_denosing\_denosing\20230516_gt1l_for_denose_AEDTA.txt

Absolute_path = fullfile(path, filename);%%绝对路径
lat_ph1 = h5read(Absolute_path,'/gt1l/heights/lat_ph') ;%读取轨线纬度
lon_ph1= h5read(Absolute_path,'/gt1l/heights/lon_ph');  %读取轨线经度
h_ph1 = h5read(Absolute_path,'/gt1l/heights/h_ph');     %读取对应经纬度点高度
signal_points = h5read(Absolute_path,'/gt1l/heights/signal_conf_ph');%读取信号点置信度
% tide_ocean =h5read(Absolute_path,'/gt3r/geophys_corr/tide_ocean');%读取对应点潮汐值

%% 折射信息导入
ref_angle= h5read(Absolute_path,'/gt1l/geolocation/ref_elev');
index_beg=h5read(Absolute_path,'/gt1l/geolocation/ph_index_beg');
segment_ph_cnt=h5read(Absolute_path,'/gt1l/geolocation/segment_ph_cnt');
reference_photon_lat=h5read(Absolute_path,'/gt1l/geolocation/reference_photon_lat');
select_conf = signal_points(2,:)';%选择海洋置信标记
%%%%

%% 读取经纬度信息
cut_lat = find(lat_ph1>=lat1 & lat_ph1<=lat2);%截取研究区范围经纬度序号
cut_lat1=lat_ph1([cut_lat(1):cut_lat(end)],1);%截取研究区范围纬度
cut_lon1=lon_ph1([cut_lat(1):cut_lat(end)],1);%截取研究区范围经度
cut_h = h_ph1([cut_lat(1):cut_lat(end)],1);%截取研究区范围高度

%% 读取去噪后光子经纬度和水深
cd F:\Data_Code\ICEsat-2_Denosing\denosed_result
filename1='AEDTA_20230516.txt';
Denosied_conf= importdata(filename1);
Denosied_conf=Denosied_conf.data;

 figure(1);
 scatter(Denosied_conf(:,1),Denosied_conf(:,3),5,'k','filled');%AEDTA去噪效果图
 title('ICESat-2 denoised')
 legend('denosed photons')
 ylim([-40 15]);  
 box on 
 %% 折射校正
cut_reference_photon_lat= find(reference_photon_lat>lat1 & reference_photon_lat<lat2);%截取研究区地底角参考光子id
cut_ref_angle = ref_angle([cut_reference_photon_lat(1):cut_reference_photon_lat(end)],1);%截取研究区地底角

n1=1.0;%空气折射率
n2=1.34;%水体折射率
angle=(pi*0.5)-cut_ref_angle(1);%pi*0.5-ref=入射角
angle2=asin((n1.*sin(angle))/n2);%折射定律求折射角
h_gcd = Denosied_conf(:,3)-sea_surface_height;%减去水面高程，得激光点观测值(绝对水深)

S =abs( h_gcd./cos(angle));%水中激光不发生折射的传输距离
R = (n1.*S)/n2;%水中激光发生折射的实际传播距离
P = sqrt(R.^2+S.^2-2.*R.*S.*cos(angle-angle2));
a = asin((sin(angle-angle2)*R)./P);
b = cut_ref_angle(1)-a;
Z = sin(b).*P;%垂直方向形变
H_ZSJZ = Denosied_conf(:,3)+Z;%折射矫正
%% 潮汐校正
%% 北京时
H_CXJZ = H_ZSJZ-sea_surface_height+HH;%潮汐矫正
Corrections=[Denosied_conf(:,1),Denosied_conf(:,2),Denosied_conf(:,3),H_ZSJZ,H_CXJZ];
% Corrections=Corrections(find(Corrections(:,1)>16.555 &Corrections(:,1)<16.58 ),:);
%折射矫正图
 figure(2);
 scatter(Corrections(:,1),Corrections(:,3),5,'k','filled');%AEDTA去噪效果图
 hold on
 scatter(Corrections(:,1),Corrections(:,4),5,'r','filled');%AEDTA去噪效果图
 title('Refraction correction')
  legend('denosed photons','Refraction correction')
  box on
  ylim([-40 15]);  

%潮汐校正图
 figure(3);
 scatter(Corrections(:,1),Corrections(:,4),5,'r','filled');%AEDTA去噪效果图
 hold on
 scatter(Corrections(:,1),Corrections(:,5),5,'g','filled');%AEDTA去噪效果图
 title('Tidal Correction')
 legend('Refraction correction','Tidal Correction ')
 box on
 ylim([-40 15]);  

% 定义CSV文件名
filename11 = '20230516_Rafr_tide_correction.csv';
filename_full = ['F:\Data_Code\ICEsat-2_Denosing\Rafr_tide_correction\', filename11];
% 打开文件以写入模式
fileID = fopen(filename_full, 'w');
% 写入表头
fprintf(fileID, '纬度,经度,水深,折射矫正后,潮汐校正后\n');
formatSpec = '%.16f,%.16f,%.16f,%.16f,%.16f\n';
% 写入数据
for i = 1:size(Corrections, 1)
    fprintf(fileID, formatSpec, Corrections(i, 1), Corrections(i, 2), Corrections(i, 3)...
        , Corrections(i, 4),Corrections(i, 5));
end
% 关闭文件
fclose(fileID);
% 提示保存成功
disp(['数据已保存到 ', filename11]);
