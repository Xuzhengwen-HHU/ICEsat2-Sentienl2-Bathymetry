%% 读取并保存Sentienl2反射率数据
clear
clc
close all
% % 读取TIF文件
cd F:\Data_Code\Sentienl-2_Bathymetry\Data
filename = 'Sentienl2_20190224_cut_ylhj.tif';
% 读取多波段TIF文件
geoinfo=geotiffinfo(filename); %####更改，影像####
% 读取数据，近岸浅水区像素点的经纬度坐标geotiffread
Height=geoinfo.Height;
Width=geoinfo.Width;
[xx,yy]=meshgrid(1:Height,1:Width);
[xx1,yy1]=pix2map(geoinfo.RefMatrix,xx,yy);%获取投影坐标
[lat,lon]=projinv(geoinfo,xx1,yy1);%% projinv将x-y投影坐标转化投影为纬度-经度坐标
lon=lon';lat=lat';

geoinfo = geotiffinfo(filename);
[Z, R] = geotiffread(filename);
% 获取影像尺寸和波段数
[Height, Width, bands] = size(Z);
% 打开输出文件

output_file = 'F:\Data_Code\Sentienl-2_Bathymetry\Data\Sen2_20190224_fanshelv.txt';
fid = fopen(output_file, 'w');
% 写入文件头
fprintf(fid, 'Latitude,Longitude');
for band = 1:bands
    fprintf(fid, ',Reflectance_Band_%d', band);
end
fprintf(fid, '\n');

% 循环处理每个像素
for row = 1:Height
    for col = 1:Width
        % 获取当前像素的经纬度
        latitude = lat(row, col);
        longitude = lon(row, col);
        % 写入经纬度
        fprintf(fid, '%.5f,%.5f', latitude, longitude);
        % 写入每个波段的反射率值
        for band = 1:bands
            reflectance = Z(row, col, band);
            fprintf(fid, ',%.5f', reflectance);
        end
        fprintf(fid, '\n');
    end
end

% 关闭文件
fclose(fid);
disp('数据已成功写入TXT文件');
