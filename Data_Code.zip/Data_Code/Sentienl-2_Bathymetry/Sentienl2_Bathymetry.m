clear;clc;close all
%% 全局字体统一设置
set(groot, ...
    'defaultAxesFontName','Times New Roman', ...
    'defaultTextFontName','Times New Roman', ...
    'defaultColorbarFontName','Times New Roman', ...
    'defaultLegendFontName','Times New Roman', ...
    'defaultAxesFontWeight','bold', ...
    'defaultTextFontWeight','bold');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% note: 获得ICEsat-2的沿轨线水深后，需要结合Sentienl-2的反射率数据反演整个平面的水深
% 第一步：将ICEsat-2的沿轨线水深重采样至与Sentienl-2同样的10m分辨率
% 第二步：将ICEsat-2的沿轨线水深作为控制点与Sentienl-2像素点配对并建立反演模型，得到模型参数
% 第三步：将上述参数应用于整个永乐环礁区域可获取整个区域的卫星反演水深（SDB）
% 第四步：用实测水深数据检验卫星反演水深（SDB）的精度
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 1.读取Icesat2水深数据集并重采样
%% 读取Icesat2水深数据集
cd F:\Data_Code\Sentienl-2_Bathymetry\Data
filename1='Icesat2_bathymetry.csv';
Data=importdata(filename1).data;
%%%做反演时刻的潮汐校正
% %%Sentienl2日期潮汐（世界时To北京时+8h,超过24h ,天数+1）
tide_20190224_11=(0.69+0.81)/2-0.95;

Depth=[Data(:,2),Data(:,1),Data(:,5)-tide_20190224_11];%% 经度，纬度，水深
data=Depth;%生成水深点位置及水深信息矩阵, 经度，纬度，水深

%% 读取反演时刻的Sentienl-2影像反射率
filename2='F:\Data_Code\Sentienl-2_Bathymetry\Data\Sen2_20190224_fanshelv.txt';
fanshelv=importdata(filename2);
fanshelv=fanshelv.data;%% 纬度，经度，反射率
dataname=('Data : 2019-02-24 ' );

%% 水深点重采样（匹配Sentienl2和Icesat2数据）
%%%%由于Sentienl2为10米分辨率的栅格图像，一个栅格中包含多个Icesat2光子点
rows=2243;cols=3654; %%%%哨兵影像的长宽像素数
lat1=min(fanshelv(:,1));lat2=max(fanshelv(:,1));lat_dt=(lat2-lat1)/rows;
lon1=min(fanshelv(:,2));lon2=max(fanshelv(:,2));lon_dt=(lon2-lon1)/cols;

[XI,YI] = meshgrid(lon1:lon_dt:lon2,lat1:lat_dt:lat2);%构建网格
x_num=size(XI,1);%读取划分网格的横坐标数2244
y_num=size(XI,2);%读取划分网格的纵坐标数3655

for x=1:y_num-1%length(XI(1,:))%重采样水深横坐标，依据22个标记点，划分为21间隔循环切片提取
    ll=find (data(:,1)>XI(1,x)&data(:,1)<XI(1,x+1));
   for y=1:x_num-1%length(YI(:,1)) %重采样水深纵坐标，依据243个标记点，划分为242间隔循环切片提取
         hh=find(data(ll,2)>YI(y,1) &data(ll,2)<YI(y+1,1));
         T(y,x)=mean(data(ll(hh),3));%以一列列数据存储重采样水深值
         Lat_resample(y,x)=mean(data(ll(hh),2));%以一列列数据存储重采样纬度值
   end
end
T=flipud(T);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 2.stumpf对数比值波段模型建立(用Icesat2所测水深与Sentienl2反射率构建模型，得到反演参数)
Band_blue=(reshape(fanshelv(:,3),cols,rows))';
Band_green=(reshape(fanshelv(:,4),cols,rows))';
Band_red=(reshape(fanshelv(:,5),cols,rows))';
Band_nir=(reshape(fanshelv(:,6),cols,rows))';

ln_b=log(Band_blue);
ln_g=log(Band_green);
ln_r=log(Band_red);
ln_nir=log(Band_nir);

X_bg=(ln_b./ln_g);
X_br=(ln_b./ln_r);
X_bn=(ln_b./ln_nir);
%由于激光数据存在多Nan值，提取有值区域做样本集
not_nan_T=find(~isnan(T));
T_use_select=T(not_nan_T);
% Lat_resample=Lat_resample(not_nan_T);
X_bg=X_bg(not_nan_T);  X_br=X_br(not_nan_T);  X_bn=X_bn(not_nan_T); 
X_b=Band_blue(not_nan_T);X_g=Band_green(not_nan_T);X_r=Band_red(not_nan_T); X_nir=Band_nir(not_nan_T);
not_nan_X=find(~isnan(X_bg));
% Lat_resample=Lat_resample(not_nan_X);
X_bg=X_bg(not_nan_X);  X_br=X_br(not_nan_X);  X_bn=X_bn(not_nan_X);
X_b=X_b(not_nan_X);X_g=X_g(not_nan_X);X_r=X_r(not_nan_X); X_nir=X_nir(not_nan_X);
T_use=T_use_select(not_nan_X);
data1 = [T_use,X_bg,X_br,X_bn]; 

data=data1((data1(:,1)<0) &(data1(:,1)>-20) ,:);%%%只选用0-20m水深段的数据
corrcoef(data(:,1),data(:,2))

% 分离Y和X
Y = data(:, 1);
X = data(:, 2:4);
XX= data(:, 2);

n = length(XX);
indices = randperm(n);
% 划分训练集和测试集
%%%%在有实测验证资料的情况下，这里的ICEsat-2测深点 全用作训练集，train_ratio = 1
%%%%在无实测验证资料的情况下，可选择1/2的ICEsat-2测深点用作训练集，另外1/2用作验证集，train_ratio = 1/2
train_ratio = 1;
n_train = round(train_ratio * n);
train_indices = indices(1:n_train);
test_indices = indices(n_train+1:end);
% 训练集
X_train = X(train_indices, :);
Y_train = Y(train_indices);

%% y=aX1+b 双波段对数比值模型
XX_train = XX(train_indices, :);
XX_train = [XX_train, ones(size(XX_train, 1), 1)];
% 拟合线性回归模型
beta_2bands = (XX_train' * XX_train) \ (XX_train' * Y_train);
% 显示拟合方程
fprintf('拟合方程: Y = %.4f*X1 + %.4f\n', beta_2bands(1), beta_2bands(2));
% 训练集预测
Y_train_pred = XX_train * beta_2bands;
% 计算平均相对误差（MRE）
MRE_train = mean(abs((Y_train - Y_train_pred) ./ Y_train));
% 计算平均绝对误差（MAE）
MAE_train = mean(abs(Y_train - Y_train_pred));
% 计算均方根误差（RMSE）
RMSE_train = sqrt(mean((Y_train - Y_train_pred).^2));
% 计算拟合R^2值
R2_train = 1 - sum((Y_train - Y_train_pred).^2) / sum((Y_train - mean(Y_train)).^2);
% 显示结果
fprintf('训练集平均相对误差（MRE）：%.4f\n', MRE_train);
fprintf('训练集平均绝对误差（MAE）：%.4f\n', MAE_train);
fprintf('训练集均方根误差（RMSE）：%.4f\n', RMSE_train);
fprintf('训练集拟合R^2值：%.4f\n', R2_train);

figure(11);
x=0:0.1:20;
y1=x;
plot(x,y1,'-',-Y_train,-Y_train_pred,'.k');
box on
xticks(0:4:20)
yticks(0:4:20)
ax = gca;
set( ax, 'xlim', [0 20], 'fontsize', 18)
set( ax, 'ylim', [0 20], 'fontsize', 18)
xlabel('ICESat-2 bathymetric depth(m)','Fontsize',18);
ylabel('Estimated depth(m)','Fontsize',18);
txt1 = (['MAE=',num2str(MAE_train,'%.2f'),'m']);
text(12,5.5,txt1,'FontSize',18)
txt2 = (['RMSE=',num2str(RMSE_train,'%.2f'),'m']);
text(12,3.5,txt2,'FontSize',18)
R=sqrt(R2_train);
txt3 = (['R=',num2str(R,'%.2f')]);
text(12,1.5,txt3,'FontSize',18)
txt4 = ('y=x');
text(20,20,txt4,'FontSize',18,'color','b');
title('Dual-band radio model ')

% picturename=('Dual-band radio model ')
% print(h,'-dpng','-r600',picturename);

%% y=aX1+bX2+cX3+d多波段对数比值模型
% 添加常数项
x = [X_train, ones(size(X_train, 1), 1)];
Y=Y_train;
% 拟合线性回归模型
beta_multi_band = (x' * x) \ (x' * Y);
% 显示拟合方程
fprintf('拟合方程: Y = %.4f*X1 + %.4f*X2 + %.4f*X3 + %.4f\n', beta_multi_band(1), beta_multi_band(2), beta_multi_band(3), beta_multi_band(4));
% 训练集预测
Y_train_pred = x * beta_multi_band;
% 计算平均相对误差（MRE）
MRE_train = mean(abs((Y_train - Y_train_pred) ./ Y_train));
% 计算平均绝对误差（MAE）
MAE_train = mean(abs(Y_train - Y_train_pred));
% 计算均方根误差（RMSE）
RMSE_train = sqrt(mean((Y_train - Y_train_pred).^2));
% 计算拟合R^2值
R2_train = 1 - sum((Y_train - Y_train_pred).^2) / sum((Y_train - mean(Y_train)).^2);
% 显示结果
fprintf('训练集平均相对误差（MRE）：%.4f\n', MRE_train);
fprintf('训练集平均绝对误差（MAE）：%.4f\n', MAE_train);
fprintf('训练集均方根误差（RMSE）：%.4f\n', RMSE_train);
fprintf('训练集拟合R^2值：%.4f\n', R2_train);

figure(12);
% set(gcf,'position',[left,bottom,width,height]);
% set(gcf,'position',[400 150 600 500])
x=0:0.1:20;
y1=x;
plot(x,y1,'-',-Y_train,-Y_train_pred,'.k','linewid',1, 'MarkerSize', 7);
box on
xticks(0:4:20)
yticks(0:4:20)
ax = gca;
set( ax, 'xlim', [0 20], 'fontsize', 18)
set( ax, 'ylim', [0 20], 'fontsize', 18)
xlabel('ICESat-2 bathymetric depth(m)','Fontsize',18);
ylabel('Estimated depth(m)','Fontsize',18);
txt1 = (['MAE=',num2str(MAE_train,'%.2f'),'m']);
text(12,5.5,txt1,'FontSize',18)
txt2 = (['RMSE=',num2str(RMSE_train,'%.2f'),'m']);
text(12,3.5,txt2,'FontSize',18)
R=sqrt(R2_train);
txt3 = (['R=',num2str(R,'%.2f')]);
text(12,1.5,txt3,'FontSize',18)
txt4 = ('y=x');
text(20,20,txt4,'FontSize',18,'color','b')
title('multiband radio model ')
% picturename=('Multiband radio model ');
% 导出图 
exportgraphics(gcf, 'F:\Data_Code\Sentienl-2_Bathymetry\result\Training.png', ...
                'Resolution', 600, 'ContentType','image', ...
               'BackgroundColor','white');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 3.区域水深反演
%利用反演公式结合反射率数据集 反演珊瑚岛区域水深值
fanshelv(:,7)=log(fanshelv(:,3))./log(fanshelv(:,4));%%反射率因子放大10000倍
fanshelv(:,8)=log(fanshelv(:,3))./log(fanshelv(:,5));%%反射率因子放大10000倍
fanshelv(:,9)=log(fanshelv(:,3))./log(fanshelv(:,6));%%反射率因子放大10000倍
X1=fanshelv(:,7);
X2=fanshelv(:,8);
X3=fanshelv(:,9);
xx=[(X1.^2) X1 ones(length(X1),1)];
xxx=[ones(length(X1),1) X1 X2 X3 (X1.^2) (X2.^2) (X3.^2)];
SDB_2Band_radio=(beta_2bands(1)).*X1+beta_2bands(2);
SDB_multi_Band_radio=(beta_multi_band(1)).*X1+beta_multi_band(2)*X2+beta_multi_band(3)*X3+beta_multi_band(4);
fanshelv(:,10)=SDB_2Band_radio;
fanshelv(:,11)=SDB_multi_Band_radio;

%% 水陆分离
% %计算NDWI
green_band=fanshelv(:,4);
nir_band=fanshelv(:,6);
ndwi = (green_band - nir_band) ./ (green_band + nir_band);
%设定阈值进行水陆分离（一般选择0作为阈值）
threshold = 0;
Land_mask = ndwi < threshold;
% 提取数据
latitude = fanshelv(:, 1); % 第一列为纬度
longitude = fanshelv(:, 2); % 第二列为经度
Land_mask_longitude=longitude(Land_mask);
Land_mask_latitude=latitude(Land_mask);
Land_mask=[Land_mask_longitude,Land_mask_latitude];

depth_2bands = fanshelv(:, 10); % 第10列为水深
depth_2bands(fanshelv(:,3)<690)=nan;%%%%%% 690是蓝波段能够反映地形变化的最小反射率，其他程序获得
depth_2bands (Land_mask==1) = nan;%%剔除反演大于0的值，视为陆地

depth_multi_band = fanshelv(:, 11); 
depth_multi_band(fanshelv(:,3)<690)=nan;
depth_multi_band (Land_mask==1) = nan;%%剔除反演大于0的值，视为陆地

%% 绘制永乐环礁地形图
% %%%%多波段比值法
figure(333)
% set(gcf,'position',[left,bottom,width,height]);
set(gcf,'position',[400 100 1100 600])
set(gca,'position', [0.10 0.1 0.79 0.86]);
% 设置投影和边界框
m_proj('Mercator', 'longitudes', [min(longitude) max(longitude)], 'latitudes', [min(latitude) max(latitude)]);%%%甘泉岛范围
% 绘制散点图
m_scatter(longitude, latitude, 2, depth_multi_band, 'filled'); % 15是点的大小，可以根据需要调整
custom_colormap = jet(10);  % 可以选择其他颜色图，如 parula(10), hot(10) 等
% 应用颜色映射
colormap(custom_colormap);
clim([-20 0]);
hold on
%%绘制陆地（绘制为黑色）
m_scatter(Land_mask(:,1), Land_mask(:,2), 1, [0.2 0.2 0.2], 'filled'); % 黑色
colorbar('ylim',[-20,0],'ytick',[-20,-16,-12,-8,-4,0]); % 添加颜色条，表示水深
h = colorbar;
h.Label.String = 'Depth(m)';
set(h,'FontSize',16);
% 添加经纬度边框和网格
m_grid('box', 'on', 'tickdir', 'in','linewi',1.5,'fontsize', 20, 'tickstyle', 'dd');
% 添加指北针
h = m_northarrow(111.485, 16.57, 0.02, 'type', 2, 'linewi', 1, 'facecolor', 'K', 'aspect', 1.09);
% %添加比例尺
m_ruler([0.13 0.33],0.73,4,'color','b',...
    'linewid',5,'tickdir','out','ticklen',0.01,'fontsize',20);

txt1 = ('Date: 2019-02-24');
m_text(111.48,16.61,txt1,'FontSize',22)
xlabel('Longitude (deg)','Fontsize',20);
ylabel('Latitude (deg)','Fontsize',20);

% 导出图 
ax = gca;
ax.Toolbar.Visible = 'off';
exportgraphics(gcf, 'F:\Data_Code\Sentienl-2_Bathymetry\result\Yongle_Bathymetry_20190224.png', ...
                'Resolution', 600, 'ContentType','image', ...
               'BackgroundColor','white');

% % 保存文件
% filename3 = [ 'Yongle_Atoll_SDB.txt'];
% filename_full = ['L:\code\Sentienl2_Bathymetry\result\', filename4];
% 
% SDB_result=[longitude,latitude,depth_multi_band];
% % 打开文件以写入模式
% fileID = fopen(filename_full,'w');
% if fileID == -1
%     error('文件无法打开');
% end
% formatSpec = '%.16f,%.16f,%.16f\n';
% % 写入表头
% fprintf(fileID, '经度,纬度,水深\n');
% % 写入数据
% for j = 1:size(SDB_result, 1)
%     fprintf(fileID, formatSpec, double(SDB_result(j, 1)), double(SDB_result(j, 2)), double(-SDB_result(j, 3)));
% end
% % 关闭文件
% fclose(fileID);
% disp(['数据已保存到 ', filename_full]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 4.实测水深数据验证SDB的精度
%% 读取验证水深数据
filename3 = 'F:\Data_Code\Sentienl-2_Bathymetry\Data\si_tu_depth.txt';
Data_situ=importdata(filename3).data;%%%%整个永乐环礁的反演数据
Data_situ=[Data_situ(17061:20552,:);Data_situ(26387:30282,:)];

lon = Data_situ(:,1);
lat = Data_situ(:,2);
hei = Data_situ(:,3);
%%%做反演时刻的潮汐校正
hei = hei-tide_20190224_11;
situ_data=[lon,lat,hei];

%% 验证水深点重采样
for x=1:y_num-1%length(XI(1,:))%重采样水深横坐标，依据22个标记点，划分为21间隔循环切片提取
    ll=find (situ_data(:,1)>XI(1,x)&situ_data(:,1)<XI(1,x+1));
   for y=1:x_num-1%length(YI(:,1)) %重采样水深纵坐标，依据243个标记点，划分为242间隔循环切片提取
         hh=find(situ_data(ll,2)>YI(y,1) &situ_data(ll,2)<YI(y+1,1));
         situ_Depth(y,x)=mean(situ_data(ll(hh),3));%以一列列数据存储重采样水深值
         Lat_resample(y,x)=mean(situ_data(ll(hh),2));%以一列列数据存储重采样纬度值
   end
end
situ_Depth=flipud(situ_Depth);

%验证数据存在多Nan值，提取有值区域做样本集
depth_2bands=(reshape(depth_2bands,cols,rows))';
depth_multi_band=(reshape(depth_multi_band,cols,rows))';

not_nan_situ_Depth=find(~isnan(situ_Depth));
situ_Depth_select1=situ_Depth(not_nan_situ_Depth);%%永乐环礁区域重采样的原位水深点
depth_2band_select1=depth_2bands(not_nan_situ_Depth);%%永乐环礁区域重采样的原位水深点处的反演水深值（双波段对数比值）
depth_multi_band_select1=depth_multi_band(not_nan_situ_Depth);%%永乐环礁区域重采样的原位水深点处的反演水深值（多波段对数比值法）
%由于将陆地和截止反射率位置的水深值置为了nan,需要筛掉
not_nan_depth_2bands_select1=find(~isnan(depth_2band_select1));
% not_nan_depth_multi_band_select1=find(~isnan(depth_multi_band_select1));%%两种反演方法非nan值区域是一样的
depth_2bands_select2=depth_2band_select1(not_nan_depth_2bands_select1);
depth_multi_band_select2=depth_multi_band_select1(not_nan_depth_2bands_select1);
situ_Depth_select2=situ_Depth_select1(not_nan_depth_2bands_select1);%%%永乐环礁区域重采样的原位水深点
%%%%%筛选出原位水深数据中0-20米的数据
mmm=find(situ_Depth_select2<20);
situ_Depth_select3=situ_Depth_select2(mmm);
depth_2bands_select3=depth_2bands_select2(mmm);
depth_multi_band_select3=depth_multi_band_select2(mmm);

%% 绘图  Sentienl2反演水深与原位水深
%% 双波段比值反演
% 计算平均绝对误差（MAE）
MAE_train = mean(abs(situ_Depth_select3 - depth_2bands_select3));
% 计算均方根误差（RMSE）
RMSE_train = sqrt(mean((situ_Depth_select3 - depth_2bands_select3).^2));
% 计算拟合R^2值
R2_train = 1 - sum((situ_Depth_select3 - depth_2bands_select3).^2) / sum((situ_Depth_select3 - mean(situ_Depth_select3)).^2);
% 显示结果
fprintf('训练集平均绝对误差（MAE）：%.4f\n', MAE_train);
fprintf('训练集均方根误差（RMSE）：%.4f\n', RMSE_train);
fprintf('训练集拟合R^2值：%.4f\n', R2_train);

depth_2bands_select3=abs(depth_2bands_select3);
% 计算平均绝对误差（MAE）
MAE_train = mean(abs(situ_Depth_select3 - depth_2bands_select3));
% 计算均方根误差（RMSE）
RMSE_train = sqrt(mean((situ_Depth_select3 - depth_2bands_select3).^2));
% 计算拟合R^2值
R2_train = 1 - sum((situ_Depth_select3 - depth_2bands_select3).^2) / sum((situ_Depth_select3 - mean(situ_Depth_select3)).^2);
% 显示结果
fprintf('训练集平均绝对误差（MAE）：%.4f\n', MAE_train);
fprintf('训练集均方根误差（RMSE）：%.4f\n', RMSE_train);
fprintf('训练集拟合R^2值：%.4f\n', R2_train);
figure(21)
x=0:0.1:20;
y1=x;
plot(x,y1,'-',situ_Depth_select3,depth_2bands_select3,'.k');
xlim([0 20]);
xticks(0:4:20)
yticks(0:4:20)
ax = gca;
set( ax, 'xlim', [0 20], 'fontsize', 18)
set( ax, 'ylim', [0 20], 'fontsize', 18)
xlabel('Measured depth(m)','Fontsize',18);
ylabel('Estimated depth(m)','Fontsize',18);
txt1 = (['MAE=',num2str(MAE_train,'%.2f'),'m']);
text(12,5.5,txt1,'FontSize',18)
txt2 = (['RMSE=',num2str(RMSE_train,'%.2f'),'m']);
text(12,3.5,txt2,'FontSize',18)
R=sqrt(R2_train);
txt3 = (['R=',num2str(R,'%.2f')]);
text(12,1.5,txt3,'FontSize',18)
txt4 = ('y=x');
text(20,20,txt4,'FontSize',18,'color','b')
title('Dual-band radio model ')

% picturename=('Dual-band radio model ')
% print(h,'-dpng','-r600',picturename);
%% 多波段比值反演
% 计算平均绝对误差（MAE）
MAE_train = mean(abs(situ_Depth_select3 - depth_multi_band_select3));
% 计算均方根误差（RMSE）
RMSE_train = sqrt(mean((situ_Depth_select3 - depth_multi_band_select3).^2));
% 计算拟合R^2值
R2_train = 1 - sum((situ_Depth_select3 - depth_multi_band_select3).^2) / sum((situ_Depth_select3 - mean(situ_Depth_select3)).^2);
% 显示结果
fprintf('训练集平均绝对误差（MAE）：%.4f\n', MAE_train);
fprintf('训练集均方根误差（RMSE）：%.4f\n', RMSE_train);
fprintf('训练集拟合R^2值：%.4f\n', R2_train);

depth_multi_band_select3=abs(depth_multi_band_select3);
% 计算平均绝对误差（MAE）
MAE_train = mean(abs(situ_Depth_select3 - depth_multi_band_select3));
% 计算均方根误差（RMSE）
RMSE_train = sqrt(mean((situ_Depth_select3 - depth_multi_band_select3).^2));
% 计算拟合R^2值
R2_train = 1 - sum((situ_Depth_select3 - depth_multi_band_select3).^2) / sum((situ_Depth_select3 - mean(situ_Depth_select3)).^2);
% 显示结果
fprintf('训练集平均绝对误差（MAE）：%.4f\n', MAE_train);
fprintf('训练集均方根误差（RMSE）：%.4f\n', RMSE_train);
fprintf('训练集拟合R^2值：%.4f\n', R2_train);

figure(22)
x=0:0.1:20;
y1=x;
plot(x,y1,'-',situ_Depth_select3,depth_multi_band_select3,'.k','linewid',1, 'MarkerSize', 7);
xlim([0 20]);
xticks(0:4:20)
yticks(0:4:20)
ax = gca;
set( ax, 'xlim', [0 20], 'fontsize', 18)
set( ax, 'ylim', [0 20], 'fontsize', 18)
xlabel('Measured depth(m)','Fontsize',18);
ylabel('Estimated depth(m)','Fontsize',18);
txt1 = (['MAE=',num2str(MAE_train,'%.2f'),'m']);
text(12,5.5,txt1,'FontSize',18)
txt2 = (['RMSE=',num2str(RMSE_train,'%.2f'),'m']);
text(12,3.5,txt2,'FontSize',18)
R=sqrt(R2_train);
txt3 = (['R=',num2str(R,'%.2f')]);
text(12,1.5,txt3,'FontSize',18)
txt4 = ('y=x');
text(20,20,txt4,'FontSize',18,'color','b')
box on
title('Multiband radio model ')

% 导出图 
exportgraphics(gcf, 'F:\Data_Code\Sentienl-2_Bathymetry\result\Validation.png', ...
                'Resolution', 600, 'ContentType','image', ...
               'BackgroundColor','white');